const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const path = require('path');

const { CLIENT_URL } = require('./config/env.config');
const apiRoutes = require('./routes/index');
const { errorHandler, notFound } = require('./middlewares/error.middleware');

const app = express();

// Security Middlewares
app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  })
);
const allowedOrigins = [
  CLIENT_URL,
  'http://localhost:5173',
  'http://localhost:3000',
  'http://127.0.0.1:5173',
  'http://127.0.0.1:3000',
].filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      if (
        allowedOrigins.includes(origin) ||
        origin.startsWith('http://localhost:') ||
        origin.startsWith('http://127.0.0.1:') ||
        CLIENT_URL === '*'
      ) {
        return callback(null, true);
      }
      return callback(null, true);
    },
    credentials: true,
  })
);

// Logging
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
}

const fs = require('fs');

const uploadsDir = path.resolve(__dirname, '../uploads');
const cwdUploadsDir = path.resolve(process.cwd(), 'uploads');

// Ensure upload and models folders exist
[
  uploadsDir,
  cwdUploadsDir,
  path.join(uploadsDir, 'models'),
  path.join(cwdUploadsDir, 'models'),
].forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Request Parsers (10mb limit for base64 uploads and image metadata)
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Static files for uploaded images / documents (Supports both /api/uploads and /uploads)
app.use('/api/uploads', express.static(uploadsDir));
app.use('/api/uploads', express.static(cwdUploadsDir));
app.use('/uploads', express.static(uploadsDir));
app.use('/uploads', express.static(cwdUploadsDir));

// Direct handler for uploaded media with local filesystem verification
app.get(['/api/uploads/:filename', '/uploads/:filename'], (req, res, next) => {
  const filename = path.basename(req.params.filename);
  const possiblePaths = [
    path.join(uploadsDir, filename),
    path.join(cwdUploadsDir, filename),
  ];

  for (const p of possiblePaths) {
    if (fs.existsSync(p)) {
      return res.sendFile(p);
    }
  }

  return next();
});

// Root Route
app.get('/', (req, res) => {
  res.status(200).json({
    message: 'Backend API is running',
  });
});

// API Routes
app.use('/api', apiRoutes);

// Error Handling Middlewares
app.use(notFound);
app.use(errorHandler);

module.exports = app;
