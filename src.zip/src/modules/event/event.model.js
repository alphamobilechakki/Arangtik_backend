const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema(
  {
    // Owner/Creator of this event
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: [true, 'User ID is required'],
      index: true,
    },

    // Event title (e.g. "Rahul & Priya Wedding", "Team Dinner")
    title: {
      type: String,
      required: [true, 'Event title is required'],
      trim: true,
      maxlength: 100,
    },

    // Event Category reference
    eventTypeId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'EventType',
      required: [true, 'Event Type is required'],
      index: true,
    },

    // Preserved snapshot of category code (e.g. 'WEDDING', 'PARTY')
    eventTypeCode: {
      type: String,
      default: '',
      uppercase: true,
      trim: true,
    },

    // Date & Time
    eventDate: {
      type: Date,
      required: [true, 'Event date is required'],
      index: true,
    },
    eventTime: {
      type: String,
      default: null, // "HH:mm" 24-hr format e.g. "19:30"
      match: [/^([01]\d|2[0-3]):([0-5]\d)$/, 'Invalid time format. Use HH:mm (e.g. 19:30)'],
    },

    // Group / Cluster IDs (To display and share this event inside user clusters/groups)
    clusterIds: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'FCCluster',
        index: true,
      },
    ],

    // Simple single-field location (No nested hassle, quick input)
    location: {
      type: String,
      trim: true,
      maxlength: 200,
      default: '',
    },

    // Styling & outfit dress code (e.g. "Traditional", "Black Tie", "Casual Chic")
    dressCode: {
      type: String,
      trim: true,
      maxlength: 80,
      default: '',
    },

    // Simple note or description
    note: {
      type: String,
      trim: true,
      maxlength: 300,
      default: '',
    },

    // Defaults (Zero friction for the user)
    timeZone: {
      type: String,
      default: 'Asia/Kolkata',
    },

    aiSuggestionsEnabled: {
      type: Boolean,
      default: true,
    },

    status: {
      type: String,
      enum: ['PLANNED', 'COMPLETED', 'CANCELLED'],
      default: 'PLANNED',
      index: true,
    },

    // Soft delete support
    isDeleted: {
      type: Boolean,
      default: false,
      index: true,
    },
    deletedAt: {
      type: Date,
      default: null,
    },
    deletedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

// Compound indexes for optimal queries
// 1. User's active events timeline
eventSchema.index({ userId: 1, isDeleted: 1, eventDate: 1 });

// 2. Events inside groups / clusters timeline
eventSchema.index({ clusterIds: 1, isDeleted: 1, eventDate: 1 });

module.exports = mongoose.models.Event || mongoose.model('Event', eventSchema);
