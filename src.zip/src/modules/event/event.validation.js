const mongoose = require('mongoose');
const ApiError = require('../../utils/apiError');

/**
 * Validate Create Event payload
 * Keeps required fields to the absolute minimum for fast creation:
 * - eventTypeId (required)
 * - eventDate (required)
 * - title (optional in body; service will auto-assign if missing)
 */
const validateCreateEvent = (req, res, next) => {
  const { eventTypeId, eventDate, eventTime, clusterIds, title, location, dressCode, note } = req.body;

  if (!eventTypeId || !mongoose.Types.ObjectId.isValid(eventTypeId)) {
    throw new ApiError(400, 'A valid eventTypeId is required');
  }

  if (!eventDate || isNaN(new Date(eventDate).getTime())) {
    throw new ApiError(400, 'A valid eventDate is required');
  }

  if (title && (typeof title !== 'string' || title.trim().length > 100)) {
    throw new ApiError(400, 'Title must be a string up to 100 characters');
  }

  if (eventTime) {
    const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;
    if (!timeRegex.test(eventTime)) {
      throw new ApiError(400, 'eventTime must be in HH:mm 24-hour format (e.g. 19:30)');
    }
  }

  if (clusterIds !== undefined) {
    if (!Array.isArray(clusterIds)) {
      throw new ApiError(400, 'clusterIds must be an array of group/cluster IDs');
    }
    for (const id of clusterIds) {
      if (!mongoose.Types.ObjectId.isValid(id)) {
        throw new ApiError(400, `Invalid cluster ID: ${id}`);
      }
    }
  }

  if (location && typeof location !== 'string') {
    throw new ApiError(400, 'Location must be a text string');
  }

  if (dressCode && typeof dressCode !== 'string') {
    throw new ApiError(400, 'dressCode must be a text string');
  }

  if (note && typeof note !== 'string') {
    throw new ApiError(400, 'Note must be a text string');
  }

  next();
};

/**
 * Validate Update Event payload
 */
const validateUpdateEvent = (req, res, next) => {
  const { id } = req.params;
  const { eventTypeId, eventDate, eventTime, clusterIds, title, location, dressCode, note, status } = req.body;

  if (!id || !mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, 'Invalid event ID parameter');
  }

  if (eventTypeId && !mongoose.Types.ObjectId.isValid(eventTypeId)) {
    throw new ApiError(400, 'Invalid eventTypeId');
  }

  if (eventDate && isNaN(new Date(eventDate).getTime())) {
    throw new ApiError(400, 'Invalid eventDate');
  }

  if (eventTime) {
    const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;
    if (!timeRegex.test(eventTime)) {
      throw new ApiError(400, 'eventTime must be in HH:mm 24-hour format');
    }
  }

  if (clusterIds !== undefined) {
    if (!Array.isArray(clusterIds)) {
      throw new ApiError(400, 'clusterIds must be an array of cluster IDs');
    }
    for (const cId of clusterIds) {
      if (!mongoose.Types.ObjectId.isValid(cId)) {
        throw new ApiError(400, `Invalid cluster ID: ${cId}`);
      }
    }
  }

  if (title && (typeof title !== 'string' || title.trim().length > 100)) {
    throw new ApiError(400, 'Title must be a string up to 100 characters');
  }

  if (status && !['PLANNED', 'COMPLETED', 'CANCELLED'].includes(status)) {
    throw new ApiError(400, 'Status must be one of PLANNED, COMPLETED, CANCELLED');
  }

  next();
};

module.exports = {
  validateCreateEvent,
  validateUpdateEvent,
};
