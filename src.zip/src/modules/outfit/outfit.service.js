const mongoose = require('mongoose');
const WardrobeItem = require('../wardrobe/wardrobeItem.model');
const Wardrobe = require('../wardrobe/wardrobe.model');
const Outfit = require('./outfit.model');
const User = require('../auth/user.model');
const clusterAccessService = require('../frequentConnect/cluster/clusterAccess.service');
const notificationService = require('../notification/notification.service');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { GEMINI_API_KEY } = require('../../config/env.config');
const ApiError = require('../../utils/apiError');
const { colord, extend: extendColord } = require('colord');
const namesPlugin = require('colord/plugins/names');
const a11yPlugin = require('colord/plugins/a11y');

extendColord([namesPlugin, a11yPlugin]);

// Standardized Slot Definitions
const SLOT_TYPES = {
  TOP: 'UPPER_WEAR',
  BOTTOM: 'LOWER_WEAR',
  ONE_PIECE: 'ONE_PIECE',
  OUTERWEAR: 'OUTERWEAR',
  FOOTWEAR: 'FOOTWEAR',
  ACCESSORIES: 'ACCESSORIES',
};

/**
 * Parses any color name or hex code dynamically using Colord library
 */
const parseFashionColor = (rawColor) => {
  if (!rawColor) return null;
  const str = rawColor.toString().toLowerCase().trim();

  // 1. Direct standard name / hex match
  let c = colord(str);
  if (c.isValid()) return c;

  // 2. Joined composite name (e.g. "dark blue" -> "darkblue", "royal blue" -> "royalblue")
  c = colord(str.replace(/[\s-]+/g, ''));
  if (c.isValid()) return c;

  // 3. First-word match (e.g. "navy blue" -> "navy", "olive green" -> "olive")
  const parts = str.split(/[\s-]+/);
  c = colord(parts[0]);
  if (c.isValid()) return c;

  // 4. Last-word fallback (e.g. "baby pink" -> "pink", "emerald green" -> "green")
  c = colord(parts[parts.length - 1]);
  return c.isValid() ? c : null;
};

/**
 * Determines if a color is a fashion neutral using HSL color physics & colord
 */
const isFashionNeutral = (colorObj, rawColorName = '') => {
  if (!colorObj) return false;
  const hsl = colorObj.toHsl();
  // Low saturation or extreme lightness levels define timeless fashion neutrals
  if (hsl.s <= 20 || hsl.l >= 90 || hsl.l <= 12) return true;
  const name = (rawColorName || '').toLowerCase();
  return ['navy', 'beige', 'tan', 'khaki', 'cream', 'taupe', 'charcoal'].some((n) => name.includes(n));
};

/**
 * Normalizes item primary color string
 */
const extractColor = (item) => {
  const c =
    item.color ||
    (item.attributes && (item.attributes.primaryColor || item.attributes.color)) ||
    '';
  return c.trim().toLowerCase();
};

/**
 * Normalizes item pattern string
 */
const extractPattern = (item) => {
  const p =
    item.pattern ||
    (item.attributes && (item.attributes.pattern || item.attributes.designPattern)) ||
    'solid';
  return p.trim().toLowerCase();
};

/**
 * Resolves the cleanest accessible image URL for an item (segmented > primary > raw)
 */
const getItemImageUrl = (item) => {
  if (Array.isArray(item.images) && item.images.length > 0) {
    const primary = item.images.find((img) => img.isPrimary);
    if (primary && primary.url) return primary.url;
    const segmented = item.images.find((img) => img.type === 'SEGMENTED');
    if (segmented && segmented.url) return segmented.url;
    return item.images[0].url || '';
  }
  return item.sourcePhotoUrl || '';
};

/**
 * Categorizes a wardrobe item into a semantic outfit slot
 * Strictly prevents Upper Wear (shirts, t-shirts, kurtas) from ever being misclassified as Lower Wear.
 */
const classifySlot = (item) => {
  if (!item) return SLOT_TYPES.TOP;

  const cat = (item.category || '').toUpperCase().trim();
  const sub = (item.subCategory || '').toLowerCase().trim();
  const name = (item.name || '').toLowerCase().trim();
  const text = `${name} ${sub}`;

  // 1. Direct Footwear Check
  if (
    cat === 'FOOTWEAR' ||
    cat === 'SHOES' ||
    /\b(shoes?|sneakers?|loafers?|heels?|boots?|sandals?|flats?|slippers?|oxfords?|brogues?|moccasins?|slides?|flip\s*flops?)\b/i.test(text)
  ) {
    return SLOT_TYPES.FOOTWEAR;
  }

  // 2. Direct Accessories Check
  if (
    cat === 'ACCESSORIES' ||
    cat === 'ACCESSORY' ||
    /\b(belts?|handbags?|bags?|watch(es)?|sunglasses?|scarf|scarves|ties?|caps?|hats?|jewell?ery|necklaces?|bracelets?|rings?|earrings?|wallets?|clutch|mufflers?|cufflinks?)\b/i.test(text)
  ) {
    return SLOT_TYPES.ACCESSORIES;
  }

  // 3. Outerwear (Blazers, Jackets, Coats, Shrugs, Overcoats)
  if (
    cat === 'OUTERWEAR' ||
    /\b(jackets?|blazers?|coats?|shrugs?|overcoats?|trench\s*coats?|bombers?|windbreakers?|cardigans?)\b/i.test(text)
  ) {
    return SLOT_TYPES.OUTERWEAR;
  }

  // 4. Explicit UPPER_WEAR / TOPS Category (ABSOLUTE PRIORITY: CAN NEVER BE LOWER_WEAR)
  if (cat === 'UPPER_WEAR' || cat === 'TOPS' || cat === 'TOP' || cat === 'UPPERWEAR') {
    // Check if it's outerwear (e.g. blazer/jacket filed under upper wear)
    if (/\b(jackets?|blazers?|coats?|shrugs?|overcoats?|bombers?)\b/i.test(text)) {
      return SLOT_TYPES.OUTERWEAR;
    }
    return SLOT_TYPES.TOP;
  }

  // 5. Explicit LOWER_WEAR / BOTTOMS Category (ABSOLUTE PRIORITY: CAN NEVER BE UPPER_WEAR)
  if (cat === 'LOWER_WEAR' || cat === 'BOTTOMS' || cat === 'BOTTOM' || cat === 'LOWERWEAR') {
    return SLOT_TYPES.BOTTOM;
  }

  // 6. Explicit ONE_PIECE / DRESS Category
  if (cat === 'ONE_PIECE' || cat === 'DRESS' || cat === 'DRESSES') {
    return SLOT_TYPES.ONE_PIECE;
  }

  // 7. Traditional / Ethnic Wear Category Nuances
  if (cat === 'TRADITIONAL') {
    // One-Piece / Full Sets (Sarees, Lehengas, Anarkalis, Kurta Sets, Salwar Suits, Sherwani Sets)
    if (/\b(sarees?|saris?|lehengas?|anarkalis?|kurta\s*sets?|salwar\s*suits?|suit\s*sets?|sherwani\s*sets?|gowns?|dresses?)\b/i.test(text)) {
      return SLOT_TYPES.ONE_PIECE;
    }
    // Traditional Lower Wear (Dhotis, Salwars, Pajamas, Churidars, Shararas, Ghararas)
    if (/\b(dhoti|dhotis|salwars?|pajamas?|pyjamas?|churidars?|shararas?|ghararas?|lungi)\b/i.test(text)) {
      return SLOT_TYPES.BOTTOM;
    }
    // Traditional Outerwear / Layer (Nehru Jacket, Bandhgala, Koti)
    if (/\b(nehru\s*jackets?|bandhgalas?|koti|waistcoats?)\b/i.test(text)) {
      return SLOT_TYPES.OUTERWEAR;
    }
    // Standalone Traditional Upper Wear (Kurtas, Kurtis, Tunics, Sherwanis) -> MUST be paired with lower wear!
    if (/\b(kurtas?|kurtis?|tunics?|sherwanis?)\b/i.test(text)) {
      return SLOT_TYPES.TOP;
    }
    // Default for TRADITIONAL: One-piece if dressy, else Top
    return SLOT_TYPES.ONE_PIECE;
  }

  // 8. One-Piece Ensembles by Keywords (Dresses, Gowns, Sarees, Jumpsuits)
  if (/\b(dres(s|ses)|gowns?|sarees?|saris?|anarkalis?|lehengas?|jumpsuits?|rompers?|kurta\s*sets?|salwar\s*suits?|co-?ords?)\b/i.test(text)) {
    return SLOT_TYPES.ONE_PIECE;
  }

  // 9. Upper Wear (Tops, Shirts, T-Shirts, Kurtas, Polos, Blouses, Sweaters) — MUST CHECK BEFORE LOWER WEAR
  // Word boundary matching ensures "short sleeve shirt" or "short kurta" matches Upper Wear
  if (/\b(shirts?|t-?shirts?|tees?|polos?|kurtas?|kurtis?|tops?|blouses?|sweaters?|sweatshirts?|hoodies?|tanks?|tank\s*tops?|camisoles?|tunics?|vests?|henleys?)\b/i.test(text)) {
    return SLOT_TYPES.TOP;
  }

  // 10. Lower Wear (Jeans, Trousers, Chinos, Pants, Shorts, Skirts)
  // Strict word boundaries prevent "short" in "short sleeve" from matching.
  // We also explicitly rule out "short sleeve" or "short kurta".
  const hasShorts = /\bshorts\b/i.test(text) && !/\bshort\s*(sleeve|sleeved|cut|collar|kurta|shirt|top|tee)\b/i.test(text);
  const isLowerWearWord = /\b(jeans?|trousers?|pants?|chinos?|skirts?|palazzos?|salwars?|joggers?|sweatpants?|cargos?|cargo\s*pants?|leggings?|jeggings?|dhotis?|pajamas?|pyjamas?|churidars?|culottes?|bermudas?|boxers?|trunks?)\b/i.test(text);

  if (hasShorts || isLowerWearWord) {
    return SLOT_TYPES.BOTTOM;
  }

  // Default fallback for tops
  return SLOT_TYPES.TOP;
};

/**
 * Calculates Color Harmony Score using Color Theory & Colord library
 */
const evaluateColorHarmony = (color1, color2) => {
  const c1Str = (color1 || '').toLowerCase().trim();
  const c2Str = (color2 || '').toLowerCase().trim();

  if (!c1Str || !c2Str) {
    return { score: 75, harmonyType: 'BALANCED', contrast: 'MEDIUM' };
  }

  // Monochromatic exact match
  if (c1Str === c2Str) {
    return { score: 85, harmonyType: 'MONOCHROMATIC', contrast: 'LOW_TONAL' };
  }

  const c1 = parseFashionColor(c1Str);
  const c2 = parseFashionColor(c2Str);

  if (!c1 || !c2) {
    return { score: 78, harmonyType: 'BALANCED', contrast: 'MEDIUM' };
  }

  const isC1Neutral = isFashionNeutral(c1, c1Str);
  const isC2Neutral = isFashionNeutral(c2, c2Str);

  // Both Neutrals -> Timeless Elegance
  if (isC1Neutral && isC2Neutral) {
    return { score: 98, harmonyType: 'TIMELESS_NEUTRALS', contrast: 'HIGH_ELEGANCE' };
  }

  // Neutral + Color Pop
  if (isC1Neutral || isC2Neutral) {
    return { score: 95, harmonyType: 'ACCENT_POP', contrast: 'DYNAMIC' };
  }

  // Hue wheel angle analysis
  const h1 = c1.toHsl().h;
  const h2 = c2.toHsl().h;
  let hueDiff = Math.abs(h1 - h2);
  if (hueDiff > 180) hueDiff = 360 - hueDiff;

  if (hueDiff <= 25) {
    return { score: 88, harmonyType: 'MONOCHROMATIC', contrast: 'LOW_TONAL' };
  }
  if (hueDiff >= 150 && hueDiff <= 180) {
    return { score: 94, harmonyType: 'COMPLEMENTARY', contrast: 'BOLD_CONTRAST' };
  }
  if (hueDiff >= 30 && hueDiff <= 65) {
    return { score: 92, harmonyType: 'ANALOGOUS', contrast: 'NATURAL_FLOW' };
  }
  if (hueDiff >= 110 && hueDiff <= 140) {
    return { score: 90, harmonyType: 'TRIADIC', contrast: 'VIBRANT_BALANCE' };
  }

  return { score: 80, harmonyType: 'CASUAL_CONTRAST', contrast: 'MEDIUM' };
};

/**
 * Occasion Appropriateness Scoring (Dynamic fallback)
 */
const scoreOccasionFit = (item, targetOccasion) => {
  const occ = (targetOccasion || 'CASUAL').toUpperCase();
  const sub = (item.subCategory || '').toLowerCase();
  const name = (item.name || '').toLowerCase();
  const text = `${name} ${sub}`;

  const itemOccasions = Array.isArray(item.occasion)
    ? item.occasion.map((o) => o.toUpperCase())
    : [];

  let score = 50;
  if (itemOccasions.includes(occ)) {
    score += 35;
  }

  const isFormalOccasion = ['OFFICE', 'FORMAL', 'WORK'].includes(occ);
  const isCasualItem = /shorts|ripped|t-shirt|tee|hoodie|jogger|flip/.test(text);
  const isFormalItem = /shirt|trouser|chino|blazer|formal|suit|oxford|loafer/.test(text);

  if (isFormalOccasion) {
    if (isFormalItem) score += 25;
    if (isCasualItem) score -= 35;
  } else if (occ === 'CASUAL' || occ === 'DAILY') {
    if (isCasualItem || /jeans|casual|polo/.test(text)) score += 20;
    if (/tuxedo|sherwani|heavy gown/.test(text)) score -= 25;
  } else if (['WEDDING', 'FESTIVE', 'TRADITIONAL'].includes(occ)) {
    if (/saree|kurta|anarkali|lehenga|sherwani|silk|ethnic|festive/.test(text)) score += 35;
    if (isCasualItem) score -= 30;
  } else {
    score += 15;
  }

  return Math.max(10, Math.min(100, score));
};

/**
 * Builds dynamic outfit title
 */
const generateOutfitTitle = (archetype, top, bottom, outerwear, occasion) => {
  const occLabel = (occasion || 'Casual').toLowerCase().replace(/^\w/, (c) => c.toUpperCase());
  if (archetype === 'ONE_PIECE') {
    return `${occLabel} Ensemble • ${top.name || top.subCategory || 'Look'}`;
  }
  const topDesc = top.name || top.subCategory || 'Top';
  const bottomDesc = bottom?.name || bottom?.subCategory || 'Bottom';
  if (outerwear) {
    return `Layered ${occLabel} • ${outerwear.name || 'Jacket'} Look`;
  }
  return `${occLabel} Pairing • ${topDesc} & ${bottomDesc}`;
};

/**
 * Builds actionable styling tips for fallback outfits
 */
const generateStylingAdvice = (archetype, top, bottom, outerwear, footwear) => {
  const tips = [];
  if (archetype === 'ONE_PIECE') {
    tips.push(`Highlight the silhouette of the ${top.name || 'ensemble'}.`);
  } else {
    tips.push(`Pair the ${top.name || 'top'} with the ${bottom?.name || 'bottom'} for a clean silhouette.`);
  }
  if (outerwear) tips.push(`Layer with ${outerwear.name} to add structure.`);
  if (footwear) tips.push(`Ground the look with ${footwear.name}.`);
  return tips.join(' ');
};

/**
 * Helper to construct standardized outfit object
 */
const buildOutfitObject = ({ archetype, primaryItems, outerwear, footwear, accessory, occasion, colorHarmony, matchScore }) => {
  const outfitItems = primaryItems.map((it) => ({
    itemId: it._id,
    slot: classifySlot(it),
    name: it.name,
    category: it.category,
    subCategory: it.subCategory,
    color: extractColor(it),
    imageUrl: getItemImageUrl(it),
  }));

  const missingSlots = [];
  if (outerwear) {
    outfitItems.push({
      itemId: outerwear._id,
      slot: SLOT_TYPES.OUTERWEAR,
      name: outerwear.name,
      category: outerwear.category,
      subCategory: outerwear.subCategory,
      color: extractColor(outerwear),
      imageUrl: getItemImageUrl(outerwear),
    });
  }
  if (footwear) {
    outfitItems.push({
      itemId: footwear._id,
      slot: SLOT_TYPES.FOOTWEAR,
      name: footwear.name,
      category: footwear.category,
      subCategory: footwear.subCategory,
      color: extractColor(footwear),
      imageUrl: getItemImageUrl(footwear),
    });
  } else {
    missingSlots.push('footwear');
  }
  if (accessory) {
    outfitItems.push({
      itemId: accessory._id,
      slot: SLOT_TYPES.ACCESSORIES,
      name: accessory.name,
      category: accessory.category,
      subCategory: accessory.subCategory,
      color: extractColor(accessory),
      imageUrl: getItemImageUrl(accessory),
    });
  }

  const top = primaryItems[0];
  const bottom = primaryItems[1] || null;

  return {
    archetype: outerwear ? 'LAYERED_TWO_PIECE' : archetype,
    title: generateOutfitTitle(archetype, top, bottom, outerwear, occasion),
    occasion: occasion.toUpperCase(),
    items: outfitItems,
    colorHarmony: {
      palette: primaryItems.map((it) => extractColor(it)).filter(Boolean),
      harmonyType: colorHarmony.harmonyType || 'DYNAMIC_HARMONY',
      contrast: colorHarmony.contrast || 'BALANCED',
      score: colorHarmony.score || 85,
    },
    matchScore,
    missingSlots,
    stylingNotes: generateStylingAdvice(archetype, top, bottom, outerwear, footwear),
  };
};

/**
 * Intelligent Personal Fashion Stylist powered by Google Gemini AI
 * Evaluates real clothes, occasion nuances, textures, silhouettes, and aesthetic trends dynamically without hardcoding.
 */
const generateOutfitsWithGemini = async (items, occasion, season, limit = 5, globalMissingSlots = [], userGender = 'UNSPECIFIED') => {
  if (!GEMINI_API_KEY || !items || items.length === 0) return null;

  const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
  const models = ['gemini-flash-lite-latest', 'gemini-3.5-flash', 'gemini-flash-latest'];

  const inventory = items.map((it) => ({
    id: it._id.toString(),
    name: it.name,
    category: it.category,
    subCategory: it.subCategory,
    slot: classifySlot(it),
    color: extractColor(it),
    pattern: extractPattern(it),
    fabric: it.fabric || it.attributes?.fabric || '',
    occasion: it.occasion || it.attributes?.occasions || [],
  }));

  const clientVibe =
    userGender === 'MALE'
      ? 'The client profile is MALE (Gentleman). Focus on sharp, tailored, flattering menswear silhouettes (shirts, t-shirts, polo, kurtas, blazers, trousers, jeans, chinos, shorts, sneakers, loafers).'
      : userGender === 'FEMALE'
      ? 'The client profile is FEMALE (Lady). Focus on chic, elegant, flattering womenswear aesthetics (tops, kurti, sarees, dresses, skirts, jeans, trousers, elegant footwear).'
      : 'Focus on versatile, modern, high-aesthetic styling combinations.';

  const prompt = `You are an elite, world-class Celebrity Fashion Stylist & Color Theory Expert for the Arangtik Digital Wardrobe Mobile App.
The user wants elevated outfit recommendations for occasion: "${occasion.toUpperCase()}"${season ? ` and season: "${season.toUpperCase()}"` : ''}.
${clientVibe}

Here is the user's REAL wardrobe inventory (DO NOT INVENT ANY ITEMS OUTSIDE THIS LIST):
${JSON.stringify(inventory, null, 2)}

CRITICAL CLOTHING COMBINATION & ANATOMICAL RULES (STRICT COMPLIANCE REQUIRED):
1. RESPECT CLOTHING SLOTS & ANATOMY:
   - "UPPER_WEAR" items (Shirts, T-Shirts, Polos, Kurtas, Tops, Hoodies, Sweaters) MUST ONLY be used as Upper Wear / Top.
   - "LOWER_WEAR" items (Pants, Trousers, Jeans, Chinos, Shorts, Joggers, Skirts) MUST ONLY be used as Lower Wear / Bottom.
   - STRICTLY FORBIDDEN: NEVER assign an UPPER_WEAR item as lower wear!
   - STRICTLY FORBIDDEN: NEVER assign a LOWER_WEAR item as upper wear!
   - STRICTLY FORBIDDEN: NEVER pair two Upper Wear items together (e.g. NEVER pair Shirt + Shirt, T-Shirt + Shirt, or Kurta + Shirt as Top and Bottom).
   - STRICTLY FORBIDDEN: NEVER pair two Lower Wear items together (e.g. NEVER pair Jeans + Pants or Jeans + Shorts).
2. OUTFIT STRUCTURE:
   - Standard Two-Piece Outfit: MUST have EXACTLY 1 Upper Wear (slot: "UPPER_WEAR") + EXACTLY 1 Lower Wear (slot: "LOWER_WEAR").
   - Layered Outfit: EXACTLY 1 Upper Wear + EXACTLY 1 Lower Wear + optionally 1 Outerwear (slot: "OUTERWEAR", e.g. blazer, jacket, coat).
   - One-Piece Ensemble: EXACTLY 1 One-Piece item (slot: "ONE_PIECE", e.g. Dress, Saree, Kurta Set) + optional Outerwear.
   - Optional Polish: You may include 1 Footwear (slot: "FOOTWEAR") and 1 Accessory (slot: "ACCESSORIES") if available in the inventory.
3. MENSWEAR RULES:
   - For men, always pair an appropriate Upper Wear (Shirt, T-Shirt, Polo, Kurta) with a matching Lower Wear (Trousers, Jeans, Chinos, Shorts).
   - A Kurta is an Upper Wear garment; it MUST be paired with a Lower Wear bottom (Pajama, Chinos, Jeans, Trousers).
4. COLOR THEORY & HARMONY:
   - Do not combine two loud clashing patterns.
   - Balance colors using Complementary, Analogous, Monochromatic, or Neutral + Pop contrast.
5. ONLY use "id" values that exist in the inventory above. NEVER invent imaginary clothes.
6. Curate up to ${limit} distinct, highly creative, occasion-perfect outfit combinations.

Return ONLY a raw JSON array of objects (no markdown, no backticks):
[
  {
    "title": "A chic, evocative high-fashion title (e.g. 'Effortless Riviera Linen', 'Urban Monochrome Edge')",
    "itemIds": ["id1", "id2"],
    "matchScore": 95,
    "colorHarmony": {
      "palette": ["Navy Blue", "Beige"],
      "harmonyType": "ACCENT_POP",
      "description": "2-3 sentences explaining why these specific colors, tones, and textures complement each other"
    },
    "stylingNotes": "2-3 sentences of practical styling tips on how to wear this outfit (e.g. cuffing, tucking, footwear pairing, accessories)"
  }
]`;

  for (const modelName of models) {
    try {
      const model = genAI.getGenerativeModel({ model: modelName });
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Timeout on model ${modelName}`)), 4000)
      );
      const apiPromise = model.generateContent(prompt);
      const result = await Promise.race([apiPromise, timeoutPromise]);

      const text = result.response.text().trim();
      const cleanJson = text.replace(/```json/g, '').replace(/```/g, '').trim();
      const parsed = JSON.parse(cleanJson);

      if (Array.isArray(parsed) && parsed.length > 0) {
        const itemsById = new Map(items.map((it) => [it._id.toString(), it]));
        const curatedOutfits = [];

        for (let idx = 0; idx < parsed.length; idx++) {
          const combo = parsed[idx];
          if (!Array.isArray(combo.itemIds) || combo.itemIds.length === 0) continue;

          // Deduplicate item IDs in combination
          const seenIds = new Set();
          const resolvedItems = [];
          for (const rawId of combo.itemIds) {
            const idStr = rawId?.toString().trim();
            if (idStr && !seenIds.has(idStr) && itemsById.has(idStr)) {
              seenIds.add(idStr);
              resolvedItems.push(itemsById.get(idStr));
            }
          }

          if (resolvedItems.length === 0) continue;

          const tops = resolvedItems.filter((it) => classifySlot(it) === SLOT_TYPES.TOP);
          const bottoms = resolvedItems.filter((it) => classifySlot(it) === SLOT_TYPES.BOTTOM);
          const onePieces = resolvedItems.filter((it) => classifySlot(it) === SLOT_TYPES.ONE_PIECE);
          const outerwears = resolvedItems.filter((it) => classifySlot(it) === SLOT_TYPES.OUTERWEAR);
          const footwears = resolvedItems.filter((it) => classifySlot(it) === SLOT_TYPES.FOOTWEAR);
          const accessories = resolvedItems.filter((it) => classifySlot(it) === SLOT_TYPES.ACCESSORIES);

          let finalItems = [];
          let archetype = 'TWO_PIECE';

          if (onePieces.length > 0) {
            archetype = 'ONE_PIECE';
            finalItems = [
              onePieces[0],
              ...outerwears.slice(0, 1),
              ...footwears.slice(0, 1),
              ...accessories.slice(0, 1),
            ];
          } else {
            // STRICT VALIDATION: MUST have AT LEAST 1 Top AND AT LEAST 1 Bottom
            if (tops.length === 0 || bottoms.length === 0) {
              console.warn(`[OutfitStylist] Discarding invalid AI combo #${idx + 1}: missing top (${tops.length}) or bottom (${bottoms.length})`);
              continue;
            }

            const chosenTop = tops[0];
            const chosenBottom = bottoms[0];

            // STRICT SANITY CHECK: Ensure top and bottom are distinct and not cross-assigned
            if (chosenTop._id.toString() === chosenBottom._id.toString()) continue;
            if (chosenTop.category === 'LOWER_WEAR' || chosenBottom.category === 'UPPER_WEAR') continue;

            archetype = outerwears.length > 0 ? 'LAYERED_TWO_PIECE' : 'TWO_PIECE';
            finalItems = [
              chosenTop,
              chosenBottom,
              ...outerwears.slice(0, 1),
              ...footwears.slice(0, 1),
              ...accessories.slice(0, 1),
            ];
          }

          const outfitItems = finalItems.map((it) => ({
            itemId: it._id,
            slot: classifySlot(it),
            name: it.name,
            category: it.category,
            subCategory: it.subCategory,
            color: extractColor(it),
            imageUrl: getItemImageUrl(it),
          }));

          const missing = [];
          if (!finalItems.some((it) => classifySlot(it) === SLOT_TYPES.FOOTWEAR) && globalMissingSlots.includes('footwear')) {
            missing.push('footwear');
          }

          curatedOutfits.push({
            id: `outfit_${curatedOutfits.length + 1}_${Date.now().toString(36)}`,
            archetype,
            title: combo.title || generateOutfitTitle(archetype, finalItems[0], finalItems[1], outerwears[0], occasion),
            occasion: occasion.toUpperCase(),
            items: outfitItems,
            colorHarmony: {
              palette: combo.colorHarmony?.palette || finalItems.map((it) => extractColor(it)).filter(Boolean),
              harmonyType: combo.colorHarmony?.harmonyType || 'DYNAMIC_HARMONY',
              description: combo.colorHarmony?.description || '',
              score: combo.matchScore || 90,
            },
            matchScore: combo.matchScore || 92,
            missingSlots: missing,
            stylingNotes: combo.stylingNotes || generateStylingAdvice(archetype, finalItems[0], finalItems[1], outerwears[0], footwears[0]),
          });

          if (curatedOutfits.length >= limit) break;
        }

        if (curatedOutfits.length > 0) {
          console.log(`[OutfitStylist] Successfully generated ${curatedOutfits.length} AI outfits with model: ${modelName}`);
          return curatedOutfits;
        }
      }
    } catch (err) {
      console.warn(`[OutfitStylist] Model ${modelName} failed (${err.message}), trying next fallback...`);
    }
  }

  return null;
};

/**
 * Core Outfit Suggestion Engine
 */
const suggestOutfits = async (userId, options = {}) => {
  const {
    wardrobeId = null,
    wardrobeIds = null,
    occasion = 'CASUAL',
    season = null,
    limit = 5,
  } = options;

  // STEP 1: Normalize selected wardrobe IDs (multi-wardrobe checklist support)
  let selectedWardrobeIds = [];
  if (Array.isArray(wardrobeIds) && wardrobeIds.length > 0) {
    selectedWardrobeIds = wardrobeIds.map((id) => id?.toString().trim()).filter((id) => id && id !== 'all');
  } else if (typeof wardrobeIds === 'string' && wardrobeIds.trim() && wardrobeIds.trim() !== 'all') {
    selectedWardrobeIds = wardrobeIds.split(',').map((id) => id.trim()).filter((id) => id && id !== 'all');
  } else if (Array.isArray(wardrobeId) && wardrobeId.length > 0) {
    selectedWardrobeIds = wardrobeId.map((id) => id?.toString().trim()).filter((id) => id && id !== 'all');
  } else if (typeof wardrobeId === 'string' && wardrobeId.trim() && wardrobeId.trim() !== 'all') {
    selectedWardrobeIds = [wardrobeId.trim()];
  }

  // STEP 2: Query Wardrobe Items strictly scoped to user & selected wardrobe(s)
  // Strictly filter out INACTIVE garments (e.g. garments currently sent to laundry)
  const query = {
    userId,
    status: { $ne: 'INACTIVE' },
  };

  if (selectedWardrobeIds.length > 0) {
    const defaultWardrobe = await Wardrobe.findOne({ userId, isDefault: true }).lean();
    const includesDefault =
      defaultWardrobe &&
      selectedWardrobeIds.some((id) => id.toString() === defaultWardrobe._id.toString());

    if (includesDefault) {
      query.$or = [
        { wardrobeId: { $in: selectedWardrobeIds } },
        { wardrobeId: null },
        { wardrobeId: { $exists: false } },
      ];
    } else {
      query.wardrobeId = { $in: selectedWardrobeIds };
    }
  }

  const items = await WardrobeItem.find(query).lean();

  if (!items || items.length === 0) {
    return {
      success: true,
      count: 0,
      availableItemsCount: 0,
      wardrobeId: selectedWardrobeIds.length === 1 ? selectedWardrobeIds[0] : (selectedWardrobeIds.length > 1 ? selectedWardrobeIds : 'all'),
      selectedWardrobeIds: selectedWardrobeIds.length > 0 ? selectedWardrobeIds : ['all'],
      selectedWardrobesCount: selectedWardrobeIds.length,
      occasion: occasion.toUpperCase(),
      outfits: [],
      message:
        selectedWardrobeIds.length > 0
          ? `No clothing items found in the ${selectedWardrobeIds.length} selected wardrobe(s). Please add clothes to receive personalized outfit combinations.`
          : 'No clothing items found in your wardrobe. Please add clothes to receive personalized outfit combinations.',
    };
  }

  // STEP 2.5: User Profile Gender Filter & Personalization
  let userGender = (options.gender || '').toUpperCase();
  if (!userGender || userGender === 'UNSPECIFIED') {
    try {
      const userDoc = await User.findById(userId).select('gender name').lean();
      if (userDoc?.gender) {
        userGender = userDoc.gender.toUpperCase();
      }
    } catch (e) {
      // Ignore user lookup error
    }
  }

  let stylingItems = items;
  if (userGender === 'MALE') {
    const femaleOnlyCategories = ['SAREE', 'LEHENGA', 'SKIRT', 'BLOUSE', 'BRA', 'BIKINI', 'HEELS', 'GOWN'];
    const isFemalePiece = (it) => {
      const sub = (it.subCategory || '').toUpperCase();
      const cat = (it.category || '').toUpperCase();
      const g = (it.gender || it.attributes?.gender || '').toUpperCase();
      if (['WOMEN', 'FEMALE', 'GIRLS'].includes(g)) return true;
      return femaleOnlyCategories.some((f) => sub.includes(f) || cat.includes(f));
    };
    const maleItems = items.filter((it) => !isFemalePiece(it));
    if (maleItems.length >= 2) {
      stylingItems = maleItems;
    }
  } else if (userGender === 'FEMALE') {
    const maleOnlyCategories = ['SHERWANI', 'DHOTI', 'BOXER', 'TIE'];
    const isMalePiece = (it) => {
      const sub = (it.subCategory || '').toUpperCase();
      const cat = (it.category || '').toUpperCase();
      const g = (it.gender || it.attributes?.gender || '').toUpperCase();
      if (['MEN', 'MALE', 'BOYS'].includes(g)) return true;
      return maleOnlyCategories.some((m) => sub.includes(m) || cat.includes(m));
    };
    const femaleItems = items.filter((it) => !isMalePiece(it));
    if (femaleItems.length >= 2) {
      stylingItems = femaleItems;
    }
  }

  // STEP 3: Segregate items into slots
  const slots = {
    tops: [],
    bottoms: [],
    one_piece: [],
    outerwear: [],
    footwear: [],
    accessories: [],
  };

  for (const item of stylingItems) {
    const slot = classifySlot(item);
    if (slot === SLOT_TYPES.TOP) slots.tops.push(item);
    else if (slot === SLOT_TYPES.BOTTOM) slots.bottoms.push(item);
    else if (slot === SLOT_TYPES.ONE_PIECE) slots.one_piece.push(item);
    else if (slot === SLOT_TYPES.OUTERWEAR) slots.outerwear.push(item);
    else if (slot === SLOT_TYPES.FOOTWEAR) slots.footwear.push(item);
    else if (slot === SLOT_TYPES.ACCESSORIES) slots.accessories.push(item);
  }

  const globalMissingSlots = [];
  if (slots.footwear.length === 0) globalMissingSlots.push('footwear');
  if (slots.outerwear.length === 0) globalMissingSlots.push('outerwear');
  if (slots.accessories.length === 0) globalMissingSlots.push('accessories');
  if (slots.tops.length === 0 && slots.one_piece.length === 0) globalMissingSlots.push('tops');
  if (slots.bottoms.length === 0 && slots.one_piece.length === 0) globalMissingSlots.push('bottoms');

  // STEP 4: PRIMARY ENGINE — Gemini AI Fashion Stylist
  if (GEMINI_API_KEY) {
    try {
      const aiOutfits = await generateOutfitsWithGemini(stylingItems, occasion, season, limit, globalMissingSlots, userGender);
      if (Array.isArray(aiOutfits) && aiOutfits.length > 0) {
        return {
          success: true,
          count: aiOutfits.length,
          availableItemsCount: items.length,
          clientGender: userGender,
          wardrobeId: selectedWardrobeIds.length === 1 ? selectedWardrobeIds[0] : (selectedWardrobeIds.length > 1 ? selectedWardrobeIds : 'all'),
          selectedWardrobeIds: selectedWardrobeIds.length > 0 ? selectedWardrobeIds : ['all'],
          selectedWardrobesCount: selectedWardrobeIds.length,
          occasion: occasion.toUpperCase(),
          missingSlots: globalMissingSlots,
          outfits: aiOutfits,
          engine: 'GEMINI_AI_STYLIST',
        };
      }
    } catch (aiErr) {
      console.warn('[OutfitStylist] Gemini AI Stylist error, engaging clean fallback:', aiErr.message);
    }
  }

  // STEP 5: CLEAN DETERMINISTIC FALLBACK (Zero Downtime)
  const combinations = [];
  const chosenOuterwear = slots.outerwear.length > 0
    ? slots.outerwear.sort((a, b) => scoreOccasionFit(b, occasion) - scoreOccasionFit(a, occasion))[0]
    : null;
  const chosenFootwear = slots.footwear.length > 0
    ? slots.footwear.sort((a, b) => scoreOccasionFit(b, occasion) - scoreOccasionFit(a, occasion))[0]
    : null;
  const chosenAccessory = slots.accessories[0] || null;

  // Combination A: Tops + Bottoms
  for (const top of slots.tops) {
    const topOccScore = scoreOccasionFit(top, occasion);
    const topColor = extractColor(top);
    const topPattern = extractPattern(top);

    for (const bottom of slots.bottoms) {
      // Guard against identical item or cross-categorized inversion
      if (top._id && bottom._id && top._id.toString() === bottom._id.toString()) continue;
      if (top.category === 'LOWER_WEAR' || bottom.category === 'UPPER_WEAR') continue;

      const bottomPattern = extractPattern(bottom);
      if (topPattern !== 'solid' && topPattern !== 'plain' && bottomPattern !== 'solid' && bottomPattern !== 'plain') {
        continue; // Prevent clashing busy patterns
      }

      const bottomColor = extractColor(bottom);
      const bottomOccScore = scoreOccasionFit(bottom, occasion);
      const harmony = evaluateColorHarmony(topColor, bottomColor);
      const totalScore = Math.round(((topOccScore + bottomOccScore) / 2) * 0.5 + harmony.score * 0.5);

      combinations.push(
        buildOutfitObject({
          archetype: 'TWO_PIECE',
          primaryItems: [top, bottom],
          outerwear: chosenOuterwear,
          footwear: chosenFootwear,
          accessory: chosenAccessory,
          occasion,
          colorHarmony: harmony,
          matchScore: totalScore,
        })
      );
    }
  }

  // Combination B: One-Piece Ensembles
  for (const piece of slots.one_piece) {
    const pieceOccScore = scoreOccasionFit(piece, occasion);
    combinations.push(
      buildOutfitObject({
        archetype: 'ONE_PIECE',
        primaryItems: [piece],
        outerwear: chosenOuterwear,
        footwear: chosenFootwear,
        accessory: chosenAccessory,
        occasion,
        colorHarmony: { harmonyType: 'SOLO_STATEMENT', contrast: 'HARMONIOUS', score: 95 },
        matchScore: Math.round(pieceOccScore * 0.7 + 95 * 0.3),
      })
    );
  }

  if (combinations.length === 0) {
    return {
      success: true,
      count: 0,
      availableItemsCount: items.length,
      wardrobeId: selectedWardrobeIds.length === 1 ? selectedWardrobeIds[0] : (selectedWardrobeIds.length > 1 ? selectedWardrobeIds : 'all'),
      selectedWardrobeIds: selectedWardrobeIds.length > 0 ? selectedWardrobeIds : ['all'],
      selectedWardrobesCount: selectedWardrobeIds.length,
      occasion: occasion.toUpperCase(),
      outfits: [],
      message: `You have ${items.length} item(s) in the ${selectedWardrobeIds.length > 0 ? selectedWardrobeIds.length + ' selected' : 'all'} wardrobe(s), but need complementary items (e.g. matching tops and bottoms, or dresses) to generate complete outfit combinations.`,
      missingSlots: globalMissingSlots,
    };
  }

  // Rank and deduplicate
  combinations.sort((a, b) => b.matchScore - a.matchScore);
  const seenKeys = new Set();
  const diverseOutfits = [];

  for (const combo of combinations) {
    const key = combo.items.map((i) => i.itemId.toString()).sort().join('-');
    if (!seenKeys.has(key)) {
      seenKeys.add(key);
      diverseOutfits.push({
        ...combo,
        id: `outfit_${diverseOutfits.length + 1}_${Date.now().toString(36)}`,
      });
    }
    if (diverseOutfits.length >= limit) break;
  }

  return {
    success: true,
    count: diverseOutfits.length,
    availableItemsCount: items.length,
    wardrobeId: selectedWardrobeIds.length === 1 ? selectedWardrobeIds[0] : (selectedWardrobeIds.length > 1 ? selectedWardrobeIds : 'all'),
    selectedWardrobeIds: selectedWardrobeIds.length > 0 ? selectedWardrobeIds : ['all'],
    selectedWardrobesCount: selectedWardrobeIds.length,
    occasion: occasion.toUpperCase(),
    missingSlots: globalMissingSlots,
    outfits: diverseOutfits,
  };
};

/**
 * Save an outfit to user's saved/bookmarked outfits
 * Supports collaborative styling across cluster members (with attribution & FCM notifications)
 */
const saveOutfit = async (userId, outfitData) => {
  const {
    wardrobeId = null,
    targetUserId: rawTargetUserId,
    clusterId: rawClusterId,
    title,
    occasion,
    season = 'ALL_SEASON',
    items,
    stylingNotes = '',
    colorHarmony = {},
    matchScore = 90,
    missingSlots = [],
  } = outfitData;

  if (!title || !occasion || !Array.isArray(items) || items.length === 0) {
    throw new ApiError(400, 'Title, occasion, and clothing items are required to save an outfit');
  }

  const targetUserId = rawTargetUserId ? String(rawTargetUserId) : String(userId);
  const isCollaborative = targetUserId !== String(userId);
  let resolvedClusterId = rawClusterId || null;

  if (isCollaborative) {
    const accessResult = await clusterAccessService.assertAccess(userId, targetUserId, 'WARDROBE', rawClusterId);
    resolvedClusterId = accessResult.cluster ? accessResult.cluster._id : (rawClusterId || null);
  }

  const itemIds = items.map((i) => i.itemId);
  const foundItems = await WardrobeItem.find({
    _id: { $in: itemIds },
  }).populate('userId', 'name').lean();

  if (foundItems.length === 0) {
    throw new ApiError(400, 'Invalid items: None of the specified clothing items could be found');
  }

  // Verify that all items belong either to the target user or creator, or accessible cluster member
  for (const found of foundItems) {
    const ownerStr = String(found.userId?._id || found.userId);
    if (ownerStr !== String(userId) && ownerStr !== targetUserId) {
      await clusterAccessService.assertAccess(userId, ownerStr, 'WARDROBE', resolvedClusterId);
    }
  }

  const enrichedItems = items.map((item) => {
    const dbItem = foundItems.find((f) => String(f._id) === String(item.itemId));
    return {
      itemId: item.itemId,
      slot: item.slot,
      name: item.name || dbItem?.name || '',
      category: item.category || dbItem?.category || '',
      subCategory: item.subCategory || dbItem?.subCategory || '',
      color: item.color || dbItem?.color || '',
      imageUrl: item.imageUrl || (dbItem ? getItemImageUrl(dbItem) : ''),
      ownerId: dbItem ? (dbItem.userId?._id || dbItem.userId) : null,
      ownerName: dbItem?.userId?.name || '',
    };
  });

  const saved = await Outfit.create({
    userId: targetUserId,
    targetUserId,
    createdBy: userId,
    clusterId: resolvedClusterId,
    wardrobeId: wardrobeId || null,
    title,
    occasion: occasion.toUpperCase(),
    season,
    items: enrichedItems,
    stylingNotes,
    colorHarmony,
    matchScore,
    missingSlots,
    status: isCollaborative ? 'SUGGESTED' : 'PERSONAL',
    isFavorite: !isCollaborative,
  });

  // If collaborative, send push notification to target user asynchronously
  if (isCollaborative) {
    User.findById(userId).select('name').lean().then(async (creator) => {
      const creatorName = creator?.name || 'A cluster member';
      await notificationService.sendToUser(targetUserId, {
        title: 'New Outfit Styled for You! 👗',
        body: `${creatorName} just styled an outfit for you: "${title}". Check it out in your wardrobe!`,
        data: {
          type: 'OUTFIT_SUGGESTION',
          outfitId: String(saved._id),
          clusterId: resolvedClusterId ? String(resolvedClusterId) : '',
        },
        type: 'OUTFIT_SUGGESTION',
      });

      // Phase 5: Log to FCAuditLog
      try {
        const fcAuditLogService = require('../frequentConnect/audit/fcAuditLog.service');
        await fcAuditLogService.logEvent({
          eventCategory: 'OUTFIT',
          action: 'OUTFIT_STYLED',
          actorId: userId,
          targetType: 'OUTFIT',
          targetId: saved._id,
          clusterId: resolvedClusterId,
          metadata: {
            title,
            targetUserId: String(targetUserId),
            itemCount: enrichedItems.length,
          },
        });
      } catch (_) {}

      // Phase 5: Post activity card into Cluster Chat if conversation exists
      if (resolvedClusterId) {
        try {
          const Cluster = require('../frequentConnect/cluster/cluster.model');
          const clusterDoc = await Cluster.findById(resolvedClusterId).select('conversationId');
          if (clusterDoc && clusterDoc.conversationId) {
            const messageService = require('../frequentConnect/message/message.service');
            const targetUserDoc = await User.findById(targetUserId).select('name').lean();
            const targetName = targetUserDoc?.name || 'Member';
            await messageService.sendMessage(clusterDoc.conversationId, userId, {
              content: `👗 ${creatorName} styled a new look for ${targetName}: "${title}"!`,
              messageType: 'TEXT',
              metadata: {
                type: 'OUTFIT_STYLED',
                outfitId: String(saved._id),
                targetUserId: String(targetUserId),
              },
            });
          }
        } catch (msgErr) {
          console.warn('[saveOutfit Cluster Chat]:', msgErr.message);
        }
      }
    }).catch((notifErr) => console.warn('[saveOutfit] push notification warning:', notifErr.message));
  }

  return saved;
};

/**
 * Get all saved outfits for user
 * Supports scopes: 'mine' | 'styled_for_me' | 'styled_by_me' | 'cluster' | 'all'
 */
const getSavedOutfits = async (userId, queryParams = {}) => {
  const { wardrobeId, occasion, scope, clusterId, status } = queryParams;
  const andClauses = [];

  if (scope === 'mine') {
    andClauses.push({ targetUserId: userId, createdBy: userId });
  } else if (scope === 'styled_for_me') {
    andClauses.push({ targetUserId: userId, createdBy: { $ne: userId } });
  } else if (scope === 'styled_by_me') {
    andClauses.push({ createdBy: userId, targetUserId: { $ne: userId } });
  } else if (scope === 'cluster' && clusterId) {
    await clusterAccessService.getAccessibleOwnerIds(userId, 'WARDROBE', clusterId);
    const cIdObj = mongoose.Types.ObjectId.isValid(clusterId) ? new mongoose.Types.ObjectId(clusterId) : clusterId;
    andClauses.push({ clusterId: cIdObj });
  } else {
    // Default: Return all outfits relevant to the user (either target user or creator)
    andClauses.push({
      $or: [
        { targetUserId: userId },
        { createdBy: userId },
        { userId },
      ],
    });
  }

  if (wardrobeId && wardrobeId !== 'all') {
    andClauses.push({ wardrobeId });
  }
  if (occasion) {
    andClauses.push({ occasion: occasion.toUpperCase() });
  }
  if (status) {
    andClauses.push({ status: String(status).toUpperCase() });
  }

  const filter = andClauses.length === 1 ? andClauses[0] : { $and: andClauses };

  const outfits = await Outfit.find(filter)
    .populate('createdBy', 'name phone profilePicture')
    .populate('targetUserId', 'name phone profilePicture')
    .populate('clusterId', 'name color code')
    .populate('items.itemId', 'name category subCategory images color pattern isFavorite')
    .sort({ createdAt: -1 })
    .lean();

  return outfits;
};

/**
 * Update outfit status (target user can accept/decline or mark worn)
 */
const updateOutfitStatus = async (userId, outfitId, status) => {
  if (!mongoose.Types.ObjectId.isValid(outfitId)) {
    throw new ApiError(400, 'Invalid outfit ID');
  }
  const normStatus = String(status).toUpperCase();
  const allowed = ['PERSONAL', 'SUGGESTED', 'ACCEPTED', 'DECLINED', 'WORN'];
  if (!allowed.includes(normStatus)) {
    throw new ApiError(400, `Invalid status. Must be one of: ${allowed.join(', ')}`);
  }

  const outfit = await Outfit.findById(outfitId);
  if (!outfit) {
    throw new ApiError(404, 'Saved outfit not found');
  }

  const isTarget = String(outfit.targetUserId || outfit.userId) === String(userId);
  const isCreator = String(outfit.createdBy) === String(userId);

  if (!isTarget && !isCreator) {
    throw new ApiError(403, 'You do not have permission to update this outfit status');
  }

  outfit.status = normStatus;
  if (normStatus === 'WORN') {
    outfit.wearCount = (outfit.wearCount || 0) + 1;
    outfit.lastWornAt = new Date();

    const itemIds = (outfit.items || []).map((i) => i.itemId).filter(Boolean);
    if (itemIds.length > 0) {
      await WardrobeItem.updateMany(
        { _id: { $in: itemIds } },
        {
          $inc: { wearCount: 1 },
          $set: { lastWornAt: new Date() },
        }
      );
    }
  }

  await outfit.save();

  // Phase 5: Log to FCAuditLog & Broadcast to Cluster Group Chat on ACCEPTED or WORN
  if (outfit.clusterId && (normStatus === 'ACCEPTED' || normStatus === 'WORN')) {
    try {
      const fcAuditLogService = require('../frequentConnect/audit/fcAuditLog.service');
      fcAuditLogService.logEvent({
        eventCategory: 'OUTFIT',
        action: 'OUTFIT_STATUS_UPDATED',
        actorId: userId,
        targetType: 'OUTFIT',
        targetId: outfit._id,
        clusterId: outfit.clusterId,
        metadata: {
          status: normStatus,
          title: outfit.title,
        },
      });

      const Cluster = require('../frequentConnect/cluster/cluster.model');
      const clusterDoc = await Cluster.findById(outfit.clusterId).select('conversationId');
      if (clusterDoc && clusterDoc.conversationId) {
        const messageService = require('../frequentConnect/message/message.service');
        const actor = await User.findById(userId).select('name').lean();
        const actorName = actor?.name || 'A member';
        const actionText = normStatus === 'WORN' ? 'is wearing' : 'accepted';
        await messageService.sendMessage(clusterDoc.conversationId, userId, {
          content: `✨ ${actorName} ${actionText} the outfit: "${outfit.title}"!`,
          messageType: 'TEXT',
          metadata: {
            type: 'OUTFIT_STATUS_UPDATED',
            outfitId: String(outfit._id),
            status: normStatus,
          },
        });
      }
    } catch (e) {
      console.warn('[updateOutfitStatus Group Chat]:', e.message);
    }
  }

  return outfit;
};

/**
 * Delete a saved outfit
 */
const deleteSavedOutfit = async (userId, outfitId) => {
  if (!mongoose.Types.ObjectId.isValid(outfitId)) {
    throw new ApiError(400, 'Invalid outfit ID');
  }

  const outfit = await Outfit.findById(outfitId);
  if (!outfit) {
    throw new ApiError(404, 'Saved outfit not found');
  }

  const isTarget = String(outfit.targetUserId || outfit.userId) === String(userId);
  const isCreator = String(outfit.createdBy) === String(userId);

  if (!isTarget && !isCreator) {
    throw new ApiError(403, 'You do not have permission to delete this outfit');
  }

  await Outfit.deleteOne({ _id: outfitId });
  return { success: true, message: 'Outfit removed successfully' };
};

module.exports = {
  suggestOutfits,
  saveOutfit,
  getSavedOutfits,
  updateOutfitStatus,
  deleteSavedOutfit,
  classifySlot,
  evaluateColorHarmony,
  scoreOccasionFit,
};
