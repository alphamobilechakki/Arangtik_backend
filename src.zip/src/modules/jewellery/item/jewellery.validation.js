const mongoose = require('mongoose');
const ApiError = require('../../../utils/apiError');

const VALID_TYPES = ['GOLD', 'SILVER', 'ARTIFICIAL', 'CUSTOM'];
const VALID_STATUSES = ['IN_LOCKER', 'LEND', 'CLEANING', 'OTHER'];

const validateSingleItemFields = (item = {}, indexLabel = '') => {
  const prefix = indexLabel ? `${indexLabel}: ` : '';
  const { name, type, status, weight } = item;

  if (name !== undefined && name !== null && name !== '') {
    if (typeof name !== 'string') {
      throw new ApiError(400, `${prefix}Jewellery name must be a string`);
    }
    if (name.trim().length > 120) {
      throw new ApiError(400, `${prefix}Name cannot exceed 120 characters`);
    }
  }

  if (type !== undefined) {
    if (!VALID_TYPES.includes(String(type).toUpperCase().trim())) {
      throw new ApiError(400, `${prefix}Type must be one of: ${VALID_TYPES.join(', ')}`);
    }
  }

  if (status !== undefined) {
    if (!VALID_STATUSES.includes(String(status).toUpperCase().trim())) {
      throw new ApiError(400, `${prefix}Status must be one of: ${VALID_STATUSES.join(', ')}`);
    }
  }

  if (weight !== undefined && weight !== null && weight !== '') {
    const num = Number(weight);
    if (isNaN(num) || num < 0) {
      throw new ApiError(400, `${prefix}Weight must be a non-negative number`);
    }
  }
};

const validateCreateItem = (req, res, next) => {
  try {
    let { items, name, sourceImageUrl, generatedImageUrl, sourceImageUrls } = req.body || {};

    if (typeof items === 'string' && items.trim()) {
      try {
        items = JSON.parse(items);
        req.body.items = items;
      } catch (err) {
        return next(new ApiError(400, 'Invalid items JSON format'));
      }
    }

    if (items !== undefined) {
      if (!Array.isArray(items) || items.length === 0) {
        return next(new ApiError(400, 'items must be a non-empty array'));
      }
      items.forEach((item, idx) => validateSingleItemFields(item, `Item ${idx + 1}`));
      return next();
    }

    const hasUploadedFiles =
      (req.files?.images?.length || 0) +
        (req.files?.sourceImage?.length || 0) +
        (req.files?.image?.length || 0) +
        (req.files?.generatedImage?.length || 0) >
      0;
    const hasImageInput =
      hasUploadedFiles ||
      Boolean(sourceImageUrl) ||
      Boolean(generatedImageUrl) ||
      (Array.isArray(sourceImageUrls) && sourceImageUrls.length > 0) ||
      (typeof sourceImageUrls === 'string' && sourceImageUrls.trim() !== '');

    if (!hasImageInput && (!name || typeof name !== 'string' || !name.trim())) {
      return next(new ApiError(400, 'At least one image or jewellery name is required'));
    }

    validateSingleItemFields(req.body || {});
    return next();
  } catch (err) {
    return next(err);
  }
};

const validateUpdateItem = (req, res, next) => {
  const { name, type, status, weight } = req.body;

  if (name !== undefined) {
    if (typeof name !== 'string' || !name.trim()) {
      return next(new ApiError(400, 'Jewellery name cannot be empty'));
    }
    if (name.trim().length > 120) {
      return next(new ApiError(400, 'Name cannot exceed 120 characters'));
    }
  }

  if (type !== undefined) {
    const validTypes = ['GOLD', 'SILVER', 'ARTIFICIAL', 'CUSTOM'];
    if (!validTypes.includes(String(type).toUpperCase().trim())) {
      return next(new ApiError(400, `Type must be one of: ${validTypes.join(', ')}`));
    }
  }

  if (status !== undefined) {
    const validStatuses = ['IN_LOCKER', 'LEND', 'CLEANING', 'OTHER'];
    if (!validStatuses.includes(String(status).toUpperCase().trim())) {
      return next(new ApiError(400, `Status must be one of: ${validStatuses.join(', ')}`));
    }
  }

  if (weight !== undefined && weight !== null && weight !== '') {
    const num = Number(weight);
    if (isNaN(num) || num < 0) {
      return next(new ApiError(400, 'Weight must be a non-negative number'));
    }
  }

  next();
};

const validateStatusUpdate = (req, res, next) => {
  const { status } = req.body;
  if (!status) {
    return next(new ApiError(400, 'Status is required'));
  }
  const validStatuses = ['IN_LOCKER', 'LEND', 'CLEANING', 'OTHER'];
  if (!validStatuses.includes(String(status).toUpperCase().trim())) {
    return next(new ApiError(400, `Status must be one of: ${validStatuses.join(', ')}`));
  }
  next();
};

const validateMoveItem = (req, res, next) => {
  const { targetJewelleryBoxId } = req.body;
  if (!targetJewelleryBoxId || !mongoose.Types.ObjectId.isValid(targetJewelleryBoxId)) {
    return next(new ApiError(400, 'Valid targetJewelleryBoxId is required'));
  }
  next();
};

const validateItemId = (req, res, next) => {
  const { id } = req.params;
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return next(new ApiError(400, 'Invalid jewellery item ID'));
  }
  next();
};

module.exports = {
  validateCreateItem,
  validateUpdateItem,
  validateStatusUpdate,
  validateMoveItem,
  validateItemId,
};
